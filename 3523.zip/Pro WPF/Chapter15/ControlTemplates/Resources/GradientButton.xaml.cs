using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;

namespace ControlTemplates
{
    public partial class GradientButton : ResourceDictionary
    {
        public GradientButton()
        {
            InitializeComponent();
        }
    }
}
