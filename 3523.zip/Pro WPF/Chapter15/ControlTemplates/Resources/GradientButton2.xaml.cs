using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;

namespace ControlTemplates
{
    public partial class GradientButton2 : ResourceDictionary
    {
        public GradientButton2()
        {
            InitializeComponent();
        }
    }
}
