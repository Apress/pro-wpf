using System;
using System.Collections.Generic;
using System.Text;

namespace Microsoft.SDK.Samples.VistaBridge.Interop
{
    internal enum NativeDialogShowState
    {
        PreShow,
        Showing,
        Closing, 
        Closed
    }
}
