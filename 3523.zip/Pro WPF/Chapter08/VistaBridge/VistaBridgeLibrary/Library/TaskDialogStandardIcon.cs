using System;
using System.Collections.Generic;
using System.Text;

namespace Microsoft.SDK.Samples.VistaBridge.Library
{
    public enum TaskDialogStandardIcon
    {
        Warning = 65535,
        Error = 65534,
        Information = 65533,
        Shield = 65532 
    }
}
