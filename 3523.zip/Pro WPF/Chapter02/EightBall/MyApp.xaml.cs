using System;
using System.Windows;
using System.Data;
using System.Xml;
using System.Configuration;

namespace ShakespeareanInsultGenerator
{
    /// <summary>
    /// Interaction logic for MyApp.xaml
    /// </summary>

    public partial class MyApp : Application
    {

    }
}